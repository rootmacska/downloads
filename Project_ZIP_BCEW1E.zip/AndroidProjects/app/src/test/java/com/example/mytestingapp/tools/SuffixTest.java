package com.example.mytestingapp.tools;

import org.junit.Test;

import static org.junit.Assert.*;

import java.io.IOException;

public class SuffixTest {

    // Valid string and number
    @Test
    public void simpleCheck() {
        Suffix s = new Suffix("string", 1);
        try {
            assertEquals(s.getStringWithSuffix(), "strings");
        } catch (IOException e) {
            fail();
        }
    }

    // Invalid Number - length greater than string length
    @Test
    public void numberIsGreaterThanStringLength() {
        Suffix s = new Suffix("string", 7);
        try {
            s.getStringWithSuffix();
            fail();
        } catch (IOException e) {
            assertEquals(e.getMessage(),"Number is greater than length of string");
        }
    }

    //Invalid number - not a number
    @Test
    public void numberIsNotValid() {
        Suffix s = new Suffix("string", 7);
        try {
            s.getStringWithSuffix();
            fail();
        } catch (IOException e) {
            assertEquals(e.getMessage(),"Number is greater than length of string");
        }
    }
}