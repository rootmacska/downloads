package com.example.mytestingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.mytestingapp.tools.Suffix;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        final Button button = findViewById(R.id.button);
        final EditText in1 = findViewById(R.id.input1);
        final EditText in2 = findViewById(R.id.input2);
        final TextView out = findViewById(R.id.out);

        button.setOnClickListener(view -> {
            String str1s = in1.getText().toString();
            String num2s = in2.getText().toString();

            int num2;

            try {
                num2 = Integer.parseInt(num2s);
            } catch (NumberFormatException e) {
                out.setText(R.string.in2_error);
                return;
            }

            Suffix suffix = new Suffix(str1s, num2);

            try {
                out.setText("Result is " + suffix.getStringWithSuffix());
            } catch (Exception e) {
                out.setText(e.getMessage());
            }
        });


    }
}