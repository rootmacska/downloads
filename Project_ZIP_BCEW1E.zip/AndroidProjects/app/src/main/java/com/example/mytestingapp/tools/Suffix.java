package com.example.mytestingapp.tools;

import java.io.IOException;

public class Suffix {
    String str;
    Integer num;

    public Suffix(String str, Integer num) {
        this.str = str;
        this.num = num;
    }

    public String getStringWithSuffix() throws IOException {
        String ans = "";
        int strLength = this.str.length();

        if(strLength == 0)
            throw new IOException("Empty String for First Argument");

        if(this.num == 0)
            return this.str;

        if(this.num < 0)
            throw new IOException("Invalid! Number less than 0");

        if(this.num > strLength) {
            throw new IOException("Number is greater than length of string");
        }
        ans = this.str + str.charAt(this.num-1);
        return ans;
    }
}
